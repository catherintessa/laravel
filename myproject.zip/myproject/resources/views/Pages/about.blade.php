@extends('Layouts.app')
@section('content')
<h1>Mariya</h1>
<b><i><h3>Ajce</h3></i></b>
@endsection