
<form method="POST" action="{{ route('shares.update',$value1->id)}}">
@method('PATCH')
@csrf
<table>
<tr>
<th>Title</th>
<td>
<input type="text" name="title"  value={{$value1->title}}/>
</td>
</tr>
<tr>
<th>Body</th>
<td>
<input type="text" name="body" value={{$value1->body}} />
</td>
</tr>
<td><center>
<input type="submit" value="submit"/></center>
</td>
</table>
</form>