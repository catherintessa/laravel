<form method="POST" action="{{ route('shares.store')}}">
@csrf
<table>
<tr>
<th>Title</th>
<td>
<input type="text" name="title"/>
</td>
</tr>
<tr>
<th>Body</th>
<td>
<input type="text" name="body"/>
</td>
</tr>
<td><center>
<input type="submit" value="submit"/></center>
</td>
</table>
</form>