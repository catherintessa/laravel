
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
@extends('layouts.tessa')
@section('content')
<h1>hello all</h1>
<h2>{{$titles}}</h2>
@endsection
</body>
</html>
