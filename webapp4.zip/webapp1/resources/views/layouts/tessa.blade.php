
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div>
<a href="/index">Home</a>
<a href="/about">about</a>
<a href="/service">Service</a>
</div>
@yield('content')
</body>
</html>
