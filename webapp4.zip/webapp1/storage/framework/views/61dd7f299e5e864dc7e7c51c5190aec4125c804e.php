<form method="POST" action="<?php echo e(route('shares.store')); ?>">
<?php echo csrf_field(); ?>
<table>
<tr>
<th>Title</th>
<td>
<input type="text" name="title"/>
</td>
</tr>
<tr>
<th>Body</th>
<td>
<input type="text" name="body"/>
</td>
</tr>
<td><center>
<input type="submit" value="submit"/></center>
</td>
</table>
</form>