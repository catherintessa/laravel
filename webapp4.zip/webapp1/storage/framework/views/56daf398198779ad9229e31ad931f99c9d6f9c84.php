<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php $__env->startSection('content'); ?>
<h1>hello all</h1>
<h2><?php echo e($titles); ?></h2>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.tessa', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>