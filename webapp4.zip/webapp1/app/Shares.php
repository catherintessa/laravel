<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shares extends Model
{
   public $fillable=[
   'title',
   'body'];
    //
}
