<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    //
	public function index()
	{
		//return "hai tessa";
		$name="tessa";
		//return view('pages.index'),compact('name'));
		return view('pages.index')->with('titles',$name);
	}
	public function about()
	{
		//return "hai tessa";
		return view('pages.about');
	}
	public function service()
	{
		//return "hai tessa";
		return view('pages.service');
	}
}
